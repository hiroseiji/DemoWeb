<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>ViB Mobile</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header page-scroll">
					<div class="navbar-header page-scroll">
					
					 <style>
    .redText
    {
        color:red;
        font-weight:bold;
    }
    .blackText
    {
        color:black;
        font-weight:bold;
    }
</style>

<h2><span class="redText">ViB</span>&nbsp;<span class="blackText">Mobile</span></h2>
				
                    </div>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>
						<li>
							<a class="page-scroll" href="homepage.php">Home</a>
						</li>
						<li>
							<a class="page-scroll" href="#page-top">About</a>
						</li>
						
						<li>
							<a class="page-scroll" href="Portfolio.php">Portfolio</a>
						</li>
						
						<li>
							<a class="page-scroll" href="Contact.php">Contact</a>
						</li>
                         
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>
        <br/>
        <br/>
<!--AboutUs-->
        <section id="features" class="light-bg" class="section-features">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<div class="section-title">
							<h2>About Us</h2>
                            <br>
                            <strong><p>ViB Mobile is the number one developer of consumer and enterprise mobile value-added services, incorporated in Gaborone, Botswana in 2010.</strong>
                
                        <p>ViB Mobile is a telecommunications company that specializes in value-added services that enhance the consumer's digital lifestyle as well as provide support for mobile operators.</p>
                        </div>
                    </div>
                </div>
         
                        
                <br/> 
                <h4>Our line of services include but are not limited to:</h4>
                <br/>
				<div class="row row-gutter">
					<div class="col-md-4 col-gutter">
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-envelope"></i></div>
							<div class="featured-text">
								<h4>SMS</h4>
								<p>One-Way and Two-Way SMS Messaging USSD Services.</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-whatsapp"></i></div>
							<div class="featured-text">
								<h4>WhatsApp Services</h4>
								<p> Demo</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-newspaper-o"></i></div>
							<div class="featured-text">
								<h4>Mobile Content Services</h4>
								<p>Caller Back Ringtones, Ringtones, etc.</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-gutter">
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-indent"></i></div>
							<div class="featured-text">
								<h4>Demo</h4>
								<p>Demo</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-paste"></i></div>
							<div class="featured-text">
								<h4>Demo</h4>
								<p>Demo</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-dollar"></i></div>
							<div class="featured-text">
								<h4>Demo</h4>
								<p>Demo</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-gutter">
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-font"></i></div>
							<div class="featured-text">
								<h4>Demo</h4>
								<p>Demo</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-wordpress"></i></div>
							<div class="featured-text">
								<h4>Demo</h4>
								<p>Demo</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-file-code-o"></i></div>
							<div class="featured-text">
								<h4>Demo</h4>
								<p>Demo</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		
        
       <br/>
        <br/>
        <br/>
        <br/>
		<footer>
			<div class="container text-center">
				<p>ViB Group © 2019 Copyright</p>
			</div>
		</footer>